import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sugerido-detalle',
  templateUrl: './sugerido-detalle.page.html',
  styleUrls: ['./sugerido-detalle.page.scss'],
})
export class SugeridoDetallePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
