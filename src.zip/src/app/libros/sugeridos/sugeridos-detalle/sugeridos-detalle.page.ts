import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sugeridos-detalle',
  templateUrl: './sugeridos-detalle.page.html',
  styleUrls: ['./sugeridos-detalle.page.scss'],
})
export class SugeridosDetallePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
