import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sugeridos',
  templateUrl: './sugeridos.page.html',
  styleUrls: ['./sugeridos.page.scss'],
})
export class SugeridosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
