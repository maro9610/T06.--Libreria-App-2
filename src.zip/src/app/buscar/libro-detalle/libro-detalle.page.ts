import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-libro-detalle',
  templateUrl: './libro-detalle.page.html',
  styleUrls: ['./libro-detalle.page.scss'],
})
export class LibroDetallePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
