import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nueva-categoria',
  templateUrl: './nueva-categoria.page.html',
  styleUrls: ['./nueva-categoria.page.scss'],
})
export class NuevaCategoriaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
